const images = ["images/slide1.jpg", "images/slide2.jpg", "images/slide3.jpg"];
let index = 0;

function showNextImage() {
  index = (index + 1) % images.length;
  document.getElementById("sliderImage").src = images[index];
}

setInterval(showNextImage, 3000);
